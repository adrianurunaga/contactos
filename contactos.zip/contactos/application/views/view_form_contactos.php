<h1>Nuevo Contacto</h1>
<br/><br/>
<?php
$input_con_email = array(
        'name'          => 'con_email',
        'id'            => 'con_email',
        'maxlength'     => '100',
        'size'          => '100',
        'value'         => set_value('con_email',@$datos_contacto[0]->con_email)
);
$input_con_nombre = array(
        'name'          => 'con_nombre',
        'id'            => 'con_nombre',
        'maxlength'     => '100',
        'size'          => '100',
        'value'         => set_value('con_nombre',@$datos_contacto[0]->con_nombre)
);
$input_con_telefono = array(
        'name'          => 'con_telefono',
        'id'            => 'con_telefono',
        'maxlength'     => '100',
        'size'          => '100',
        'value'         => set_value('con_telefono',@$datos_contacto[0]->con_telefono)
);
$input_con_edad = array(
        'name'          => 'con_edad',
        'id'            => 'con_edad',
        'maxlength'     => '100',
        'size'          => '100',
        'value'         => set_value('con_edad',@$datos_contacto[0]->con_edad)
);
$opciones = array(
    '0' => 'Inactivo',
    '1' => 'Activo',
);

?>
<!-- <?php echo validation_errors(); ?> -->

<?php echo form_open()?><br/>

<?php echo form_label('Email')?><br/>
<?php echo form_input($input_con_email)?><br/> <?php echo form_error('con_email')?><br/>
<?php echo form_label('Nombre')?><br/>
<?php echo form_input($input_con_nombre)?><br/> <?php echo form_error('con_nombre')?><br/>
<?php echo form_label('Telefono')?><br/>
<?php echo form_input($input_con_telefono)?><br/> <?php echo form_error('con_telefono')?><br/>
<?php echo form_label('Edad')?><br/>
<?php echo form_input($input_con_edad)?><br/> <?php echo form_error('con_edad')?><br/>

<?php echo form_label('Status')?><br/>
<?php echo form_dropdown('con_status',$opciones,set_value('con_status',@$datos_contacto[0]->con_status))?><br/><br/>

<?php echo form_submit('btn_enviar', 'Guardar') ?><br/>
<?php echo form_close()?>



